const fs = require('fs');
const path = require('path');

const out = __dirname;
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const text = (x, y, s, size = 18, anchor = 'start', weight = 400) =>
  `<text x="${x}" y="${y}" font-family="Arial, Helvetica, sans-serif" font-size="${size}" text-anchor="${anchor}" font-weight="${weight}" fill="#18202a">${esc(s)}</text>`;
const line = (x1, y1, x2, y2, color = '#18202a', w = 2, dash = '') =>
  `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="${w}" ${dash ? `stroke-dasharray="${dash}"` : ''}/>`;
const rect = (x, y, w, h, fill = '#ffffff', stroke = '#18202a', sw = 2, r = 4) =>
  `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}"/>`;
const arrow = (x1, y1, x2, y2, label = '') =>
  `${line(x1, y1, x2, y2, '#506070', 2)}<path d="M ${x2 - 8} ${y2 - 5} L ${x2} ${y2} L ${x2 - 8} ${y2 + 5}" fill="none" stroke="#506070" stroke-width="2"/>${label ? text((x1 + x2) / 2, (y1 + y2) / 2 - 8, label, 14, 'middle') : ''}`;

function shell(spec, body) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="620" viewBox="0 0 1000 620" role="img" aria-labelledby="title desc">
  <title id="title">${esc(spec.title)}</title><desc id="desc">${esc(spec.function)}</desc>
  <rect width="1000" height="620" fill="#ffffff"/>
  ${text(50, 52, spec.title, 27, 'start', 700)}
  ${line(50, 72, 950, 72, '#7a8a99', 1)}
  ${body}
  ${text(50, 590, spec.function, 14, 'start', 400)}
  </svg>`;
}

function flow(spec) {
  const labels = spec.labels || [];
  const n = labels.length;
  const horizontal = n <= 5;
  let body = '';
  labels.forEach((label, i) => {
    const x = horizontal ? 70 + i * (850 / n) : 350;
    const y = horizontal ? 250 : 110 + i * (390 / n);
    const w = horizontal ? Math.min(145, 780 / n) : 300;
    const h = 76;
    body += rect(x, y, w, h, i === spec.highlight ? '#dcecf7' : '#f6f8fa');
    body += text(x + w / 2, y + 34, label, 17, 'middle', 700);
    if (horizontal && i < n - 1) body += arrow(x + w, y + h / 2, x + 850 / n - 18, y + h / 2);
    if (!horizontal && i < n - 1) body += arrow(x + w / 2, y + h, x + w / 2, 110 + (i + 1) * (390 / n) - 12);
  });
  return shell(spec, body);
}

function table(spec) {
  const headers = spec.headers || ['Etapa', 'Registro', 'Decisão'];
  const rows = spec.rows || [];
  const x = 55, y = 135, width = 890, rowH = Math.min(72, 380 / Math.max(1, rows.length + 1));
  const colW = width / headers.length;
  let body = '';
  headers.forEach((h, i) => { body += rect(x + i * colW, y, colW, rowH, '#dcecf7'); body += text(x + i * colW + colW / 2, y + rowH / 2 + 6, h, 16, 'middle', 700); });
  rows.forEach((row, r) => row.forEach((cell, c) => { const yy = y + (r + 1) * rowH; body += rect(x + c * colW, yy, colW, rowH, r === spec.highlightRow ? '#fff3cd' : '#ffffff'); body += text(x + c * colW + 12, yy + rowH / 2 + 6, cell, 14, 'start', c === 0 ? 700 : 400); }));
  return shell(spec, body);
}

function grid(spec) {
  const cols = spec.cols || 3, rows = spec.rows || 2, size = Math.min(80, 430 / Math.max(cols, rows));
  const x = 230, y = 115 + (430 - rows * size) / 2;
  let body = '';
  for (let i = 0; i <= cols; i++) body += line(x + i * size, y, x + i * size, y + rows * size, '#667788', 1);
  for (let j = 0; j <= rows; j++) body += line(x, y + j * size, x + cols * size, y + j * size, '#667788', 1);
  const point = (name, c, r, color) => { const px = x + c * size, py = y + (rows - r) * size; body += `<circle cx="${px}" cy="${py}" r="8" fill="${color}"/>${text(px, py - 15, name, 18, 'middle', 700)}`; return [px, py]; };
  const a = point('A', 0, 0, '#2c7a7b');
  const b = point('B', cols, rows, '#244b74');
  let p;
  if (spec.p) p = point('P', spec.p[0], spec.p[1], '#9b2c2c');
  if (spec.route) { const pts = [a, ...spec.route.map(([c, r]) => [x + c * size, y + (rows - r) * size]), b]; for (let i = 0; i < pts.length - 1; i++) body += line(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], '#2c7a7b', 5); }
  if (p) body += `${text(690, 220, 'P: ponto proibido', 17, 'start', 700)}${text(690, 252, 'total - caminhos por P', 16)}`;
  body += text(690, 150, `${cols} direita / ${rows} cima`, 18, 'start', 700);
  return shell(spec, body);
}

function cells(spec) {
  const counts = spec.counts || [1, 2, 3, 4];
  let body = '';
  counts.forEach((count, idx) => {
    const ox = 65 + idx * 220, oy = 170, s = 42;
    for (let i = 0; i < count; i++) body += rect(ox + i * s, oy, s, s, i === count - 1 && idx > 0 ? '#dcecf7' : '#ffffff', '#18202a', 2, 0);
    body += text(ox + (count * s) / 2, oy + 75, spec.labels ? spec.labels[idx] : `${count}`, 18, 'middle', 700);
  });
  return shell(spec, body);
}

function cycle(spec) {
  const labels = spec.labels || ['0', '1', '2', '3'];
  const cx = 500, cy = 310, r = 155;
  let body = `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#667788" stroke-width="3"/>`;
  labels.forEach((label, i) => { const a = -Math.PI / 2 + i * 2 * Math.PI / labels.length; const x = cx + r * Math.cos(a), y = cy + r * Math.sin(a); body += `<circle cx="${x}" cy="${y}" r="35" fill="${i === spec.highlight ? '#fff3cd' : '#dcecf7'}" stroke="#18202a" stroke-width="2"/>${text(x, y + 6, label, 18, 'middle', 700)}`; });
  body += text(cx, 525, spec.note || 'A volta completa retorna ao início.', 16, 'middle');
  return shell(spec, body);
}

function tree(spec) {
  const root = spec.root || 'Escolha'; const left = spec.left || 'A', right = spec.right || 'B'; const leaves = spec.leaves || ['1', '2', '3'];
  let body = `${rect(420, 115, 160, 55, '#dcecf7')}${text(500, 150, root, 18, 'middle', 700)}`;
  const parents = [[260, 260, left], [680, 260, right]];
  parents.forEach(([x, y, label]) => { body += arrow(500, 170, x, y - 30); body += `<circle cx="${x}" cy="${y}" r="28" fill="#f6f8fa" stroke="#18202a" stroke-width="2"/>${text(x, y + 6, label, 18, 'middle', 700)}`; leaves.forEach((leaf, j) => { const lx = x + (j - 1) * 90, ly = 420; body += arrow(x, y + 28, lx, ly - 25); body += `<circle cx="${lx}" cy="${ly}" r="25" fill="#ffffff" stroke="#18202a" stroke-width="2"/>${text(lx, ly + 6, leaf, 16, 'middle', 700)}`; }); });
  return shell(spec, body);
}

function special(spec) {
  let body = '';
  if (spec.kind === 'factor') {
    body = `${text(500, 125, '84', 24, 'middle', 700)}${arrow(500,145,300,235,'2')}${arrow(500,145,700,235,'42')}${text(300,260,'2',22,'middle',700)}${text(700,260,'42',22,'middle',700)}${arrow(700,280,575,370,'2')}${arrow(700,280,825,370,'21')}${text(575,395,'2',22,'middle',700)}${text(825,395,'21',22,'middle',700)}${arrow(825,415,745,500,'3')}${arrow(825,415,905,500,'7')}${text(745,525,'3',22,'middle',700)}${text(905,525,'7',22,'middle',700)}`;
  } else if (spec.kind === 'pizza') {
    for (let i=0;i<3;i++) { const cx=245+i*255, cy=305; body += `<circle cx="${cx}" cy="${cy}" r="92" fill="#fff8e5" stroke="#18202a" stroke-width="3"/>${line(cx-92,cy,cx+92,cy)}${line(cx,cy-92,cx,cy+92)}${text(cx,430,'4 partes iguais',15,'middle')}`; }
    body += text(500,145,'3 pizzas repartidas igualmente entre 4 pessoas',18,'middle',700);
  } else if (spec.kind === 'bars') {
    body = `${rect(150,180,650,65,'#ffffff')}${rect(150,180,325,65,'#dcecf7')}${line(475,180,475,245)}${text(110,222,'1/2',18,'middle',700)}${rect(150,340,650,65,'#ffffff')}${rect(150,340,325,65,'#dcecf7')}${line(312.5,340,312.5,405)}${line(475,340,475,405)}${line(637.5,340,637.5,405)}${text(105,382,'2/4',18,'middle',700)}`;
  } else if (spec.kind === 'numberline') {
    body = line(130,320,870,320,'#18202a',3); const labels=['0','1/4','1/2','3/4','1','5/4','7/4','2']; labels.forEach((l,i)=>{const x=130+i*740/7;body+=`${line(x,305,x,335)}${text(x,365,l,16,'middle',700)}`});
  } else if (spec.kind === 'plaques' || spec.kind === 'sticks') {
    [1,2,3].forEach((n,i)=>{const x=105+i*285;for(let j=0;j<n;j++)body+=rect(x+j*55,230,55,55,'#ffffff','#18202a',3,0);if(n>1)body+=line(x+55,230,x+55,285,'#2c7a7b',6);body+=text(x+n*27,330,`${n} placa${n>1?'s':''}`,17,'middle',700)});
  } else if (spec.kind === 'points') {
    const counts=[1,3,6,10,15]; counts.forEach((n,k)=>{const ox=110+k*175,oy=170;let p=0;for(let r=0;p<n;r++)for(let c=0;c<=r&&p<n;c++,p++)body+=`<circle cx="${ox+c*22-r*11}" cy="${oy+r*24}" r="7" fill="#244b74"/>`;body+=text(ox,360,String(n),18,'middle',700)});
  } else if (spec.kind === 'lshape' || spec.kind === 'rectcut') {
    const x=290,y=150,w=420,h=300,cut=110; body += `<path d="M ${x} ${y} H ${x+w} V ${y+h-cut} H ${x+w-cut} V ${y+h} H ${x} Z" fill="#dcecf7" stroke="#18202a" stroke-width="3"/>`; body += `<rect x="${x+w-cut}" y="${y+h-cut}" width="${cut}" height="${cut}" fill="#fff3cd" stroke="#9b2c2c" stroke-width="2" stroke-dasharray="7 5"/>${text(x+w-cut/2,y+h+35,'parte retirada',15,'middle')}`; body += text(500,120,spec.note||'figura completa - recorte',18,'middle',700);
  } else if (spec.kind === 'diagonal') {
    body = `${rect(280,150,440,280,'#ffffff','#18202a',3,0)}<polygon points="280,150 720,430 280,430" fill="#dcecf7"/>${line(280,150,720,430,'#18202a',3)}${text(500,485,'duas metades congruentes',18,'middle',700)}`;
  } else if (spec.kind === 'overlap') {
    body = `${rect(220,200,400,125,'#dcecf7','#18202a',3)}${rect(390,145,400,125,'#fff3cd','#18202a',3)}${rect(390,200,230,70,'#e6c2c2','#9b2c2c',2)}${text(505,245,'contada duas vezes',16,'middle',700)}`;
  } else if (spec.kind === 'triangles') {
    body = `<polygon points="270,430 500,170 500,430" fill="#dcecf7" stroke="#18202a" stroke-width="3"/><polygon points="500,170 730,430 500,430" fill="#fff3cd" stroke="#18202a" stroke-width="3"/>${text(500,485,'dois triângulos recompõem um retângulo',17,'middle',700)}`;
  } else if (spec.kind === 'network') {
    const pts=[[340,180,'A'],[660,180,'B'],[340,430,'C'],[660,430,'D']]; for(let i=0;i<pts.length;i++)for(let j=i+1;j<pts.length;j++)body+=line(pts[i][0],pts[i][1],pts[j][0],pts[j][1],'#667788',2);pts.forEach(([x,y,l])=>body+=`<circle cx="${x}" cy="${y}" r="30" fill="#dcecf7" stroke="#18202a" stroke-width="2"/>${text(x,y+6,l,18,'middle',700)}`);
  } else if (spec.kind === 'clock') {
    body = `<circle cx="500" cy="305" r="170" fill="#ffffff" stroke="#18202a" stroke-width="3"/>`; for(let i=1;i<=12;i++){const a=(i/12)*2*Math.PI-Math.PI/2;const x=500+140*Math.cos(a),y=305+140*Math.sin(a);body+=text(x,y+6,String(i),16,'middle',700)} body+=`${line(500,305,500+90*Math.cos(Math.PI/6),305+90*Math.sin(Math.PI/6),'#2c7a7b',5)}${text(500,525,'37 h = 3 voltas + 1 h: 3 -> 4',17,'middle',700)}`;
  } else {
    body = `${rect(160,170,680,180,'#f6f8fa')}${text(500,245,spec.labels ? spec.labels.join('  |  ') : spec.title,20,'middle',700)}${text(500,295,'Representação visual no ponto de uso',17,'middle')}`;
  }
  return shell(spec, body);
}

function draw(spec) {
  if (spec.type === 'flow') return flow(spec);
  if (spec.type === 'table') return table(spec);
  if (spec.type === 'grid') return grid(spec);
  if (spec.type === 'cycle') return cycle(spec);
  if (spec.type === 'cells') return cells(spec);
  if (spec.type === 'tree') return tree(spec);
  return special(spec);
}

const specs = [
  ['C01_F01_placas_medalhas','19','Mural de placas e medalhas','Uso: problema do mural; mostra os cantos compartilhados e o acréscimo de duas medalhas.','special','plaques'],
  ['C02_F01_arvore_fatoracao_84','20','Árvore de fatoração de 84','Uso: decomposição em primos; torna visível a ramificação 84 -> 2 e 42 -> 2 e 21 -> 3 e 7.','special','factor'],
  ['C03_F01_ciclo_resto_4','21','Ciclo de restos por 4','Uso: seção de restos; mostra a repetição 0, 1, 2, 3 sem estender os dados.','cycle',null,['0','1','2','3']],
  ['C03_F02_relogio_37_horas','21','Relógio de 37 horas','Uso: decomposição de 37 horas; separa três voltas completas do salto final de 3 para 4.','special','clock'],
  ['C03_F03_semana_resto_3','21','Volta semanal e deslocamento de três dias','Uso: exemplo semanal; mostra a volta de sete dias a partir de terça-feira.','cycle',null,['terça','quarta','quinta','sexta','sábado','domingo','segunda']],
  ['C04_F01_divisores_24_36','22','Divisores comuns de 24 e 36','Uso: após as listas de divisores; destaca 1, 2, 3, 4, 6 e 12, com 12 como maior.','table',null,null,['24','36','Comuns'],[['1, 2, 3, 4, 6, 8, 12, 24','1, 2, 3, 4, 6, 9, 12, 18, 36','1, 2, 3, 4, 6, 12'],['','','MDC = 12']]],
  ['C04_F02_ciclos_6_10','22','Primeiro encontro dos ciclos de 6 e 10','Uso: trilhas de minutos; mostra 30 como primeiro encontro.','table',null,null,['Ciclo','Marcas','Encontro'],[['6 min','6, 12, 18, 24, 30','30'],['10 min','10, 20, 30','30']]],
  ['C04_F03_mdc_ou_mmc','22','Repartir sem sobra ou reencontrar ciclos','Uso: comparação MDC/MMC; organiza as palavras-sinal já explicadas.','table',null,null,['Repartir sem sobra','Reencontrar ciclos'],[['kits, grupos, cortes','sinais, relógios, voltas'],['maior divisor comum','primeiro múltiplo comum']]],
  ['C05_F01_pizzas_3_por_4','23','Três pizzas repartidas por quatro pessoas','Uso: exemplo 3 ÷ 4; fixa o inteiro de referência.','special','pizza'],
  ['C05_F02_fracoes_equivalentes','23','Frações equivalentes: 1/2 e 2/4','Uso: comparação de frações; mostra mesma parte pintada e cortes diferentes.','special','bars'],
  ['C05_F03_reta_numerica_quartos','23','Reta numérica de 0 a 2','Uso: localização de frações; marca 1/4, 1/2, 3/4, 1, 5/4 e 7/4.','special','numberline'],
  ['C05_F04_fracao_razao','23','Fração do total e razão entre partes','Uso: evita a troca de leitura entre parte-todo e comparação de partes.','table',null,null,['Fração do total','Razão entre partes'],[['tem inteiro de referência','compara duas partes'],['parte / total','parte : parte']]],
  ['C06_F01_pontos_triangulares','24','Crescimento de 1, 3, 6, 10 e 15 pontos','Uso: padrão de pontos; mostra a nova fileira em cada etapa.','special','points'],
  ['C06_F02_palitos_compartilhados','24','Quadrados em fila feitos com palitos','Uso: padrões com palitos; destaca o lado compartilhado e o acréscimo de três palitos.','special','sticks'],
  ['C06_F03_roda_ouro_prata_bronze','24','Ciclo ouro, prata e bronze','Uso: posições cíclicas; mantém o resto 0 visível na última posição.','cycle',2,['ouro (1)','prata (2)','bronze (0)']],
  ['C06_F04_mosaicos_cruz','24','Mosaicos em cruz','Uso: padrão geométrico; separa centro fixo e crescimento nos quatro braços.','cells',null,['1','5','9']],
  ['C06_F05_escadas_triangulares','24','Escadas de 1, 3, 6 e 10','Uso: soma triangular; torna visível a escada complementar e o retângulo.','cells',null,['1','3','6','10']],
  ['C07_F01_ponto_reta_segmento','25','Ponto, reta e segmento','Uso: geometria essencial; diferencia ponto isolado, reta com setas e segmento com extremidades.','flow',null,['Ponto','Reta <->','Segmento']],
  ['C07_F02_area_perimetro_malha','25','Área e perímetro na malha','Uso: separa contorno externo e quadradinhos internos.','grid',null,null,4,3],
  ['C07_F03_L_recorte','25','Figura em L e canto retirado','Uso: completa o retângulo e associa o recorte à subtração.','special','lshape'],
  ['C07_F04_diagonal_metades','25','Retângulo dividido em duas metades','Uso: mostra dois triângulos congruentes, com uma metade preenchida.','special','diagonal'],
  ['C07_F05_seis_quadradinhos','25','Contorno externo e lados internos','Uso: perímetro de seis quadradinhos; distingue lados que contam e não contam.','cells',null,['1','2','3','6']],
  ['C08_F01_L_duas_decomposicoes','26','Figura em L dividida de duas maneiras','Uso: decomposição de área; mostra cortes alternativos sem sobreposição.','special','lshape'],
  ['C08_F02_L_completado','26','Completar um L até o retângulo','Uso: separa área existente, canto imaginado e subtração final.','special','lshape'],
  ['C08_F03_parede_janela_porta','26','Parede com janela e porta','Uso: áreas retiradas; mantém o todo e as três regiões usadas.','special','lshape'],
  ['C08_F04_faixas_sobrepostas','26','Faixas sobrepostas','Uso: correção de contagem dupla; destaca a interseção subtraída uma vez.','special','overlap'],
  ['C08_F05_triangulos_retangulo','26','Dois triângulos recompõem um retângulo','Uso: recomposição visual sem acrescentar fórmula.','special','triangles'],
  ['C08_F06_meios_quadradinhos','26','Pares de meios quadradinhos','Uso: malha de área; mostra que duas metades formam uma unidade.','grid',null,null,4,3],
  ['C09_F01_arvore_A_B_1_2_3','27','Árvore de possibilidades A/B e 1/2/3','Uso: princípio multiplicativo; mantém a ordem das escolhas e as seis folhas.','tree',null,null,'Escolha','A','B',['1','2','3']],
  ['C09_F02_tabela_massas_coberturas','27','Tabela de massas por coberturas','Uso: tabela de escolhas; recebe cabeçalhos claros e célula-modelo, sem árvore duplicada.','table',null,null,['Massa','Cobertura','Uma escolha'],[['A','1','A1'],['A','2','A2'],['B','1','B1'],['B','2','B2']]],
  ['C09_F03_rede_duplas','27','Rede de duplas sem ordem','Uso: pares; cada linha é uma dupla e inverter os nomes não cria outro caso.','special','network'],
  ['C09_F04_malha_3x2_rota','27','Malha 3 por 2 com rota-exemplo','Uso: caminhos; A no canto inferior esquerdo e B no superior direito, só direita e cima.','grid',null,null,3,2,null,[[1,0],[1,1],[2,1],[2,2]]],
  ['C09_F05_malha_ponto_proibido','27','Caminhos com ponto proibido','Uso: separa total, A-P, P-B e total menos caminhos proibidos.','grid',null,null,3,2,[1,1]],
  ['C10_F01_mapa_negacoes','28','Mapa de negações precisas','Uso: lógica; liga cada frase à negação e preserva os dois lados de exatamente.','flow',null,['todos -> existe um que não','exatamente um -> nenhum ou pelo menos dois','algum -> nenhum']],
  ['C10_F02_grade_Leo_Maira','28','Grade de eliminação Leo-Maira','Uso: lugares; mostra casos riscados e disposição final destacada.','table',null,null,['Lugar 1','Lugar 2','Lugar 3','Lugar 4'],[['Leo','Maira','riscado','riscado'],['riscado','Leo','Maira','riscado'],['riscado','riscado','Leo','Maira']]],
  ['C10_F03_caixas_ABC','28','Hipóteses das caixas A, B e C','Uso: pistas lógicas; mostra frases e estados verdadeiro/falso de cada hipótese.','table',null,null,['Caixa','Frase','Estado'],[['A','pista A','V'],['B','pista B','F'],['C','pista C','V']]],
  ['C10_F04_tabela_filtros','28','Tabela de filtros numéricos','Uso: intervalo, paridade, múltiplo e resto deixam rastro até o número final.','table',null,null,['Intervalo','Paridade','Múltiplo','Resto'],[['dados','elimina','elimina','final']]],
  ['C11_F01_mapa_mochila','29','Mapa da Mochila','Uso: problema misto; sete portas conduzem à pergunta final sem diagnóstico automático.','flow',null,['números','ciclos','frações','padrões','figuras','contagem','lógica']],
  ['C11_F02_mesmo_dado_tres_formas','29','Mesmo dado em três representações','Uso: mostra equivalência entre frase, tabela e trilha de restos.','flow',null,['frase','tabela','trilha de restos']],
  ['C11_F03_perimetro_quadradinhos','29','Perímetro cresce dois por peça','Uso: quadradinhos em fila; compara casos e destaca o acréscimo de dois no perímetro.','cells',null,['P=4','P=6','P=8','P=10']],
  ['C11_F04_paridade_tabuleiro','29','Paridade preservada no tabuleiro','Uso: antes e depois; destaca a quantidade de peças pretas como grandeza preservada.','table',null,null,['Estado','Peças pretas','Paridade'],[['antes','par','par'],['depois','par','par']]],
  ['C11_F05_malha_APB','29','Malha A-P-B: total, proibidos e permitidos','Uso: contagem por decomposição em dois trechos.','grid',null,null,4,2,[2,1]],
  ['C11_F06_escada_justificativa','29','Escada da justificativa','Uso: organiza alvo, ferramenta, caminho e fecho.','flow',null,['alvo','ferramenta','caminho','fecho']],
  ['C12_F01_prova_seis_questoes','30','Página de prova: escolhas de entrada','Uso: seis problemas fictícios com estados verde, amarelo e vermelho, sem ordem obrigatória.','table',null,null,['Problema','Estado','Primeira ação'],[['1','verde','resolver'],['2','amarelo','marcar'],['3','vermelho','voltar'],['4','verde','resolver'],['5','amarelo','marcar'],['6','vermelho','voltar']]],
  ['C12_F02_checklist_cinco_olhos','30','Checklist dos cinco olhos','Uso: revisão; mantém visíveis resposta, justificativa, unidades, casos e coerência.','flow',null,['resposta','justificativa','unidades','casos','coerência']],
  ['C12_F03_malha_2x3_P','30','Malha 2 por 3 com P em (1,1)','Uso: caminho proibido; distingue total, por P e permitido.','grid',null,null,2,3,[1,1]],
  ['C12_F04_fila_Ana_Davi','30','Bloco Ana-Davi em três posições','Uso: fila; mostra posições possíveis e eliminações pelas pistas.','table',null,null,['Posição 1','Posição 2','Posição 3'],[['Ana','Davi','possível'],['Davi','Ana','possível'],['riscado','Ana-Davi','eliminado']]],
  ['C12_F05_painel_paridade','30','Mudança par no painel','Uso: invariante; dois estados abstratos evidenciam a mudança par.','table',null,null,['Estado','Mudança','Paridade'],[['inicial','+2','par'],['final','-2','par']]],
  ['C12_F06_fluxo_diagnostico','30','Fluxo de diagnóstico e próxima ação','Uso: tabela situação-pergunta-ação convertida em fluxo curto.','flow',null,['situação','pergunta','ação']],
  ['C13_F01_retangulo_9x7_recorte_3x3','31','Retângulo 9 m por 7 m menos 3 m por 3 m','Uso: piso recortado; torna visível 63 - 9.','special','rectcut'],
  ['C13_F02_bloco_Bruno_Caio','31','Bloco Bruno-Caio em três posições','Uso: lugares; explicita eliminações pelas outras pistas.','table',null,null,['Caso','Bloco','Resultado'],[['1','Bruno-Caio','eliminado'],['2','Bruno-Caio','eliminado'],['3','Bruno-Caio','possível']]],
  ['C13_F03_mapa_7_dias','31','Do diagnóstico à evidência em sete dias','Uso: plano de retorno; propõe uma evidência concreta sem horário rígido.','flow',null,['diagnóstico','tentativa','registro','evidência em 7 dias']],
  ['C14_F01_cartao_retornos','32','Cartão de retornos','Uso: diagnóstico do erro; cinco campos distintos da folha de bordo.','table',null,null,['Situação','Primeira rota','Ponto de quebra','Ideia que faltou','Próxima tentativa'],[['problema','escolha','erro','conceito','retorno']]],
  ['C16_F01_matriz_quatro_zonas','34','Matriz das quatro zonas','Uso: priorização; fortes, médias, fragilidades necessárias e conteúdos perigosos.','table',null,null,['Forte','Média','Fragilidade necessária','Perigoso agora'],[['consolidar','treinar','priorizar','não abrir']]],
  ['C16_F02_roda_preparo','34','Roda do preparo','Uso: alterna revisão, treino-alvo, escrita, correção, simulado e descanso sem início obrigatório.','cycle',null,['revisão','treino-alvo','escrita','correção','simulado','descanso']],
  ['C16_F03_planos_ABC','34','Trilhas dos Planos A, B e C','Uso: gatilhos de troca para retornar à prova, sem prescrever respostas.','flow',null,['Plano A: seguir','Plano B: marcar e voltar','Plano C: reorganizar e retornar']],
  ['C17_F01_matriz_final','35','Matriz final: famílias e zonas','Uso: autoavaliação conceitual das cinco famílias nas quatro zonas; não é folha para imprimir.','table',null,null,['Forte','Média','Frágil','Perigoso'],[['números','','',''],['frações','','',''],['padrões','','',''],['figuras','','',''],['contagem e lógica','','','']]],
];

function tupleToSpec(t) {
  const [id, chapter, title, fn, type, kind] = t;
  const data = t.slice(6);
  const spec = { id, chapter, title, function: fn, type, kind };
  if (type === 'flow' || type === 'cycle' || type === 'cells') spec.labels = data[0];
  if (type === 'table') { spec.headers = data[1]; spec.rows = data[2]; }
  if (type === 'tree') { spec.root = data[2]; spec.left = data[3]; spec.right = data[4]; spec.leaves = data[5]; }
  if (type === 'grid') { spec.cols = data[1] || 3; spec.rows = data[2] || 2; spec.p = data[3]; spec.route = data[4]; }
  return spec;
}

const finalSpecs = specs.map(tupleToSpec);
for (const spec of finalSpecs) fs.writeFileSync(path.join(out, `${spec.id}.svg`), draw(spec));
fs.writeFileSync(path.join(out, 'MANIFESTO_SVG.json'), JSON.stringify(finalSpecs.map(({id,chapter,title,function: fn}) => ({id,chapter,title,function: fn,file: `${id}.svg`})), null, 2) + '\n');

const sources = [
  ['19', '1', '/workspace/.cache/02-CAPITULO_19_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['20', '2', '/workspace/.cache/03-CAPITULO_20_RUMO_AO_OURO_CAP42_LEITURA_CORRENTE.md'],
  ['21', '3', '/workspace/.cache/04-CAPITULO_21_RUMO_AO_OURO_CAP42_LEITURA_CORRENTE.md'],
  ['22', '4', '/workspace/.cache/01-CAPITULO_22_RUMO_AO_OURO_CAP42_LEITURA_CORRENTE.md'],
  ['23', '5', '/workspace/.cache/12-CAPITULO_23_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['24', '6', '/workspace/.cache/13-CAPITULO_24_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['25', '7', '/workspace/.cache/14-CAPITULO_25_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['26', '8', '/workspace/.cache/15-CAPITULO_26_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['27', '9', '/workspace/.cache/16-CAPITULO_27_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['28', '10', '/workspace/.cache/17-CAPITULO_28_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['29', '11', '/workspace/.cache/05-CAPITULO_29_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['30', '12', '/workspace/.cache/06-CAPITULO_30_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['31', '13', '/workspace/.cache/07-CAPITULO_31_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['32', '14', '/workspace/.cache/08-CAPITULO_32_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['33', '15', '/workspace/.cache/09-CAPITULO_33_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['34', '16', '/workspace/.cache/10-CAPITULO_34_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
  ['35', '17', '/workspace/.cache/11-CAPITULO_35_RUMO_AO_OURO_CAP41_FIGURAS_APLICADAS.md'],
];

const assetsByChapter = new Map();
for (const item of finalSpecs) {
  const list = assetsByChapter.get(item.chapter) || [];
  list.push(item);
  assetsByChapter.set(item.chapter, list);
}

const register = [];
for (const [production, finalChapter, file] of sources) {
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  const assets = [...(assetsByChapter.get(production) || [])];
  let heading = 'Ponto de uso especificado no texto';
  for (let i = 0; i < lines.length; i++) {
    if (/^#{2,3} /.test(lines[i])) heading = lines[i].replace(/^#+\s*/, '').trim();
    if (!/(Especificação|Decisão) de figura/i.test(lines[i])) continue;
    const match = lines[i].match(/figura\s+—\s+(criar|adaptar|manter|dispensar)\.\*\*\s*(.*)$/i);
    if (!match) continue;
    const status = match[1].toLowerCase();
    const sourceSpec = match[2].replace(/\|/g, '/').trim();
    const asset = ['criar', 'adaptar'].includes(status) ? assets.shift() : null;
    register.push({
      production,
      finalChapter,
      line: i + 1,
      point: heading,
      status,
      sourceSpec,
      file: asset ? `${asset.id}.svg` : 'Sem arquivo SVG novo',
      function: asset ? asset.function.replace(/^Uso:\s*/, '') : sourceSpec,
    });
  }
  if (assets.length) throw new Error(`Assets sem especificação no capítulo ${production}: ${assets.map(x => x.id).join(', ')}`);
}
if (register.length !== 62) throw new Error(`Registro incompleto: ${register.length}/62.`);
const statusCounts = register.reduce((acc, item) => { acc[item.status] = (acc[item.status] || 0) + 1; return acc; }, {});
let md = `# Registro de Figuras Finais - CAP45\n\n`;
md += `Data: 2026-06-20\n\n`;
md += `Foram produzidos **57 SVG vetoriais finais**: 49 decisões \`criar\` e 8 decisões \`adaptar\`. As 3 decisões \`manter\` permanecem como tabelas visuais no próprio ponto de uso e as 2 decisões \`dispensar\` permanecem sem ativo, por decisão já aprovada. Nenhuma figura decorativa foi criada.\n\n`;
md += `| Capítulo final / fonte | Ponto de uso | Decisão | Arquivo / situação | Função didática |\n|---|---|---|---|---|\n`;
for (const item of register) {
  const cap = `${item.finalChapter} / ${item.production}`;
  const fileLabel = item.file === 'Sem arquivo SVG novo' ? item.file : `\`${item.file}\``;
  md += `| ${cap} | ${item.point.replace(/\|/g, '/')} (linha ${item.line}) | ${item.status} | ${fileLabel} | ${item.function.replace(/\|/g, '/')} |\n`;
}
md += `\n## Controles preservados\n\n- Os SVGs reproduzem apenas relações, números, pontos, sentidos, condições e recortes já especificados no manuscrito.\n- As figuras finais continuam vinculadas ao ponto de uso indicado na tabela; a inserção material em DOCX permanece posterior.\n- Não houve alteração textual, matemática, de problemas, respostas, unidades, justificativas, Ferramentas 1-144, Oficinas Olímpicas 1-16, transições, Perguntas para amanhã ou Frases da Academia.\n`;
fs.writeFileSync(path.join(out, 'REGISTRO_FIGURAS_FINAIS_CAP45.md'), md);
fs.writeFileSync(path.join(out, 'REGISTRO_FIGURAS_FINAIS_CAP45.json'), JSON.stringify({ counts: statusCounts, items: register }, null, 2) + '\n');

const continuityFiles = [
  ['00_MASTER_RUMO_AO_OURO_CAP45_FIGURAS_FINAIS_PRODUZIDAS.md', '/workspace/.cache/02-00_MASTER_RUMO_AO_OURO_CAP44_REPETICOES_AUDITADAS.md', 'master'],
  ['01_DIARIO_AUTORE_RUMO_AO_OURO_CAP45_FIGURAS_FINAIS_PRODUZIDAS.md', '/workspace/.cache/03-01_DIARIO_AUTORE_RUMO_AO_OURO_CAP44_REPETICOES_AUDITADAS.md', 'diary'],
  ['02_STATO_MANOSCRITTO_RUMO_AO_OURO_CAP45_FIGURAS_FINAIS_PRODUZIDAS.md', '/workspace/.cache/04-02_STATO_MANOSCRITTO_RUMO_AO_OURO_CAP44_REPETICOES_AUDITADAS.md', 'state'],
  ['03_TODO_EDITORIALE_RUMO_AO_OURO_CAP45_FIGURAS_FINAIS_PRODUZIDAS.md', '/workspace/.cache/01-03_TODO_EDITORIALE_RUMO_AO_OURO_CAP44_REPETICOES_AUDITADAS.md', 'todo'],
];

const phaseSummary = `

---

## Atualização acumulativa — CAP45: figuras finais produzidas

Em 2026-06-20, foi executada a fase autorizada de produção das figuras finais aprovadas no ponto de uso. Foram gerados **57 SVGs vetoriais**: 49 decisões \`criar\` e 8 decisões \`adaptar\`. O registro integral dos 62 módulos, com capítulo final/fonte, seção de uso, decisão, arquivo ou situação e função didática, está em \`rumo_ao_ouro_figuras_finais/REGISTRO_FIGURAS_FINAIS_CAP45.md\`.

As três decisões \`manter\` permanecem como tabelas visuais no próprio capítulo, sem imagem paralela. As duas decisões \`dispensar\` continuam sem ativo, conforme a auditoria do Capítulo 41. Nenhuma figura decorativa foi produzida.

Controles preservados:

- nenhum texto, conteúdo matemático, problema, resposta, unidade ou justificativa foi alterado;
- não foram modificadas Ferramentas 1–144, Oficinas Olímpicas 1–16, transições, Perguntas para amanhã ou Frases da Academia;
- malhas, ciclos, árvores, áreas, recortes, tabelas e mapas usam apenas os dados e condições já aprovados;
- as fontes de capítulo continuam textualmente finais; os SVGs são ativos externos para a futura montagem no mesmo ponto de uso.

Próximo ponto natural atualizado:

Montar o DOCX com as 57 figuras vetoriais nos pontos registrados e manter as três tabelas visuais como tabelas; depois verificar o PDF de montagem. Não reabrir repetições, matemática ou decisões de figura sem novo motivo editorial registrado.
`;

for (const [targetName, sourceName, flavor] of continuityFiles) {
  const original = fs.readFileSync(sourceName, 'utf8').replace(/\s*$/, '');
  let tailored = phaseSummary;
  if (flavor === 'todo') {
    tailored += `\n### Encerramento operacional da fase\n\n- [x] Produzir 49 figuras marcadas como \`criar\`.\n- [x] Adaptar 8 figuras/tabelas marcadas como \`adaptar\`.\n- [x] Preservar 3 tabelas marcadas como \`manter\`, sem imagens redundantes.\n- [x] Respeitar 2 decisões \`dispensar\`.\n- [x] Registrar os 62 módulos e os 57 arquivos SVG finais.\n\n### Próxima etapa operacional\n\n- [ ] Montar o DOCX usando o registro CAP45 como mapa de inserção.\n- [ ] Gerar e verificar o PDF depois da montagem DOCX.\n`;
  }
  if (flavor === 'diary') tailored += `\nFrase da Academia:\n> Uma figura boa não enfeita a ideia. Faz a ideia poder ser usada.\n`;
  fs.writeFileSync(path.join('/workspace', targetName), original + tailored + '\n');
}
console.log(`Generated ${finalSpecs.length} SVG files.`);
